from collections import defaultdict
import random
import fileOperations as fileOp
import nlpTask as nlp
import uniqueLogging
import time
import difflib
import operator
from random import shuffle
from fuzzywuzzy import process



unique_logger=uniqueLogging.unique_logging()

def find_similar_response(answerDict, questionList,question):
	similarity=[]
	similarity_dict={}
	summary_list=[]
	result_quest_list=[]
	result_tuple=[]
	score_list=[]
	MAX_LIMIT=5
	THRESHOLD_VALUE=0.8
	try:
		similarity=process.extract(question,questionList,limit=MAX_LIMIT)
		for rowResult in similarity:
			similarity_dict[rowResult[0]]=rowResult[1]
    		result=sorted(similarity_dict.items(), key=operator.itemgetter(1), reverse=True)[:5]
		if (result[0][1]/100.0) > THRESHOLD_VALUE:
			result_tuple.append((question, answerDict[result[0][0]], result[0][1]/100.0))
			
		else:
			for resultIndex in range(len(result)):
				result_tuple.append((question,answerDict[result[resultIndex][0]], result[resultIndex][1]/100.0))
		return result_tuple
			
			

	except Exception ,e:
		unique_logger.error('Exception Occured.........')
		unique_logger.error('Exception Details........%s',e)

	
if __name__=='__main__':
	try:
		tin=time.time()
		question_filename='personality_question.pkl'
		answer_filename='personality_answer.pkl'
		question_dict=fileOp.read_pickle_file(question_filename)
		answer_dict=fileOp.read_pickle_file(answer_filename)
		while True:
			question=raw_input('Enter Query')
			print find_similar_response(question_dict, answer_dict,question.lower())
	except Exception,e:
		unique_logger.error('Exception occured.......')
		unique_logger.error('Exception Details.......%s',e)




